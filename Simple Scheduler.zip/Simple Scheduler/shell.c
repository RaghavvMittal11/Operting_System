#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "scheduler.h"
sem_t semaphore;
int min(int a, int b) {
    return (a < b) ? a : b;
}

typedef struct Data {
    char** command;
    pid_t pid;
    clock_t start_time;
    clock_t end_time;
} Data;

typedef struct Node {
    Data data;
    struct Node* prev;
    struct Node* next;
} Node;

// Function to create a new node
Node* createNode(Data data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        perror("Failed to allocate memory for new node");
        exit(EXIT_FAILURE);
    }
    newNode->data = data;
    newNode->prev = NULL;
    newNode->next = NULL;
    return newNode;
}

void addNode(Node** listEnd, Node* newNode) {
    if (listEnd == NULL || newNode == NULL) {
        return; // Optionally handle this case
    }
    if (*listEnd != NULL) { // Only do this if listEnd is not NULL
        (*listEnd)->next = newNode; // Dereference to access the pointer to the node
        newNode->prev = *listEnd;    // Set the previous pointer
    }
    *listEnd = newNode;          // Update the listEnd to point to the new node
}

void printArgs(char* args[]) {
   for (int i = 0; args[i] != NULL; i++) {
        printf("Argument %d: %s\n", i, args[i]);
    }
    return;
}

// Execute a single command
void command(char** args, Node** listEnd,bool isBack) {
    pid_t pid = fork();
    Data dat;
    dat.command = args;
    dat.start_time = clock();

    if (pid < 0) {
        printf("Something bad happened here\n");
        exit(0);
    } else if (pid == 0) {
        execvp(args[0], args);
        perror("execvp failed");
        exit(0);
    } else {
        if(isBack){
                printf("Background process starts: %d\n",pid);
        }
        else{
                wait(NULL);
        }
        dat.pid = pid;
        dat.end_time = clock();
        Node *newNode = createNode(dat);

        if (*listEnd != NULL) { // If listEnd is not NULL
            (*listEnd)->next = newNode;   // Set the next of listEnd to newNode
            newNode->prev = *listEnd;     // Set newNode's previous to listEnd
        }
        *listEnd = newNode; // Update listEnd to point to newNode
    }
    return;
}

// Parse the command into arguments without using in-built functions
int func(char* cmd, char** argv, Node** listNode) {
    int k = 0; // cmd pointer
    int j = 0; // argv pointer
    int arg_index = 0;
    char temp[100]; // Fixed size buffer for temporary storage

    // Loop through each character in the command string
    while (cmd[k] != '\0') {
        if (cmd[k] == ' ') { // End of an argument
            temp[arg_index] = '\0'; // Null terminate the argument
            argv[j] = (char*)malloc(strlen(temp) + 1);
            // Allocate memory for argument
             if (argv[j] == NULL) {
                perror("Failed to allocate memory for argument");
                exit(EXIT_FAILURE);
            }

            for (int i = 0; temp[i] != '\0'; i++) { // Copy temp to argv[j]
                argv[j][i] = temp[i];
            }
            argv[j][strlen(temp)] = '\0'; // Null terminate the argument in argv[j]
            j++;
            arg_index = 0; // Reset temp index for the next argument
        } else {
            temp[arg_index] = cmd[k];
            arg_index++;
        }
        k++;
    }

    // Copy the last argument
    temp[arg_index] = '\0';
    argv[j] = (char*)malloc(strlen(temp) + 1);
    if (argv[j] == NULL) {
    perror("Failed to allocate memory for last argument");
     exit(EXIT_FAILURE);
    }

    for (int i = 0; temp[i] != '\0'; i++) {
        argv[j][i] = temp[i];
    }
    argv[j][strlen(temp)] = '\0';
    j++;
    argv[j] = NULL; // Null terminate the argument list

    return j; // Return the count of arguments
}
void Pipe(char **cmd, int count, Node **listEnd) {
    int i;
    int pipefd[2];
    int prev_fd = 0;  // To hold the input file descriptor for the next process
    pid_t pid;

    for (i = 0; i < count; i++) {
        // Create a pipe
        if (i < count - 1) {
            if (pipe(pipefd) == -1) {
                perror("pipe");
                exit(EXIT_FAILURE);
            }
        }

        // Fork a new process
        pid = fork();
        if (pid == -1) {
            perror("fork");
            exit(EXIT_FAILURE);
        }

        // Manual tokenization of cmd[i] into args array
        char *args[100]; // Example size; adjust as necessary
        int j = 0;
        char *current = cmd[i];
        char *start = current;

        // Tokenize manually
        while (*current) {
            if (*current == ' ') {
                if (start != current) { // If there's a token
                    *current = '\0'; // Null-terminate the token
                    args[j++] = start; // Save the token
                }
                start = current + 1; // Move to the next character
            }
            current++;
        }
        if (start != current) { // Add the last token
            args[j++] = start;
        }
        args[j] = NULL; // Null-terminate the array

        Data dat;
        dat.command = args;
        dat.start_time = clock();

        if (pid == 0) { // Child process
            // If not the first command, get input from the previous process
            if (i > 0) {
                dup2(prev_fd, STDIN_FILENO);  // Read from prev_fd (input from the previous pipe)
                close(prev_fd);
            }

            // If not the last command, send output to the next pipe
            if (i < count - 1) {
                close(pipefd[0]);  // Close unused read end of the pipe
                dup2(pipefd[1], STDOUT_FILENO);  // Write to the pipe
                close(pipefd[1]);
            }

            // Execute the command
            execvp(args[0], args);
            perror("execvp");  // If execvp fails
            exit(EXIT_FAILURE);
        } else { // Parent process
            wait(NULL);  // Wait for child to finish
            dat.pid = pid;
            dat.end_time = clock();
            Node *newNode = createNode(dat);
            (*listEnd)->next = newNode;
            newNode->prev = *listEnd;
            *listEnd = newNode;  // Update listEnd

            // Close previous pipe read end if it exists
            if (i > 0) {
                close(prev_fd);
            }

            // Set prev_fd to the read end of the current pipe
            if (i < count - 1) {
                close(pipefd[1]);  // Close unused write end of the pipe
                prev_fd = pipefd[0];  // Save the read end for the next command
            }
        }
    }
}

void printHis(Node* listSt) {
    if (listSt == NULL) {
        printf("No history available.\n");
        return;
    }
    int i = 0;
    while (listSt != NULL) {
        if (i == 0) {
            listSt = listSt->next;
            i = 1;
            continue;
        }
        printf("Command: ");
        //for (int i = 0; listSt->data.command[i] != NULL; i++) {
        //    printf("%s ", listSt->data.command[i]);
        //}
        printf("\nPID: %d\n", listSt->data.pid);
        printf("Start Time: %ld\n", (long)listSt->data.start_time);
        printf("Duration: %ld\n", (long)listSt->data.end_time-(long)listSt->data.start_time);
        printf("-----------------------\n");

        listSt = listSt->next;
    }
}



int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Write in this format <NCPU> <TSLICE> \n");
        exit(EXIT_FAILURE);
    }

    int NCPU = atoi(argv[1]);
    int TSLICE = atoi(argv[2]);


    function1();

    pthread_t scheduler_thread; // Create a thread for the scheduler
    pthread_create(&scheduler_thread, NULL, simple_scheduler, &NCPU);

    Data dat;
    Node* listSt = createNode(dat);
    Node* listEnd = listSt;

    while (true) {
        printf("%s\n", "Shell$");
        fflush(stdout);

        char input[10000];
        char* cmds[100];

        memset(input, 0, sizeof(input));
        read(STDIN_FILENO, input, 10000);

        int len = 0;
        while (input[len] != '\n' && input[len] != '\0') {
            len++;
        }
        input[len] = '\0';

        if (strcmp(input, "exit") == 0) {
            print_completed_jobs();
            destroy_shared_memory();
            printHis(listSt);
            printf("Exiting shell...\n");
            break;
        }
        bool isBack=false;
        if(input[len-1]=='&'){
                isBack=true;
                input[len-1]='\0';
                len--;
        }
        char target[] = "submit";
        int isSubmit = 1; // Flag to check if the command starts with "submit"

        // Manual implementation of strncmp(command, "submit", 6)
        for (int i = 0; i < 6; i++) {
            if (input[i] != target[i]) {
                isSubmit = 0; // Not a "submit" command
                break;
            }
        }
        if(isSubmit){
            int i = 6;
            while (input[i] == ' ') {
                i++;
            }
            char* executable=(char*)malloc(100 * sizeof(char));

            int j = 0;
            while ( input[i] != '\0') {
                executable[j] = input[i];
                j++;
                i++;
            }
            executable[j] = '\0';

            char* argv[100];
            int count=func(executable,argv,NULL);
            submit(argv,count);
            continue;
        }

        int k = 0;
        int start = 0;
        for (int i = 0; i <= len; i++) {
            if (input[i] == '|' || input[i] == '\0') {
                cmds[k] = (char*)malloc((i - start + 1) * sizeof(char));
                int index = 0;
                for (int j = start; j < i; j++) {
                    cmds[k][index] = input[j];
                    index++;
                }
                cmds[k][index] = '\0';
                k++;
                start = i + 1;
            }
        }
        if (k > 1) {
            Pipe(cmds, k, &listEnd);
        }
        else if (k == 1) {
            char* args[10];
            int count = func(cmds[0], args, &listEnd);
            command(args, &listEnd,isBack);
        }

        for (int i = 0; i < k; i++) {
            free(cmds[i]);
        }
    }

    return 0;
}
