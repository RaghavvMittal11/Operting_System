// scheduler.h
#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>

#define MAX_QUEUE_SIZE 1000
#define MAX_PROCESSES 100

typedef struct schedule {
    int pid;
    clock_t completion_time;
    int wait_time;
    clock_t stop;
    int running;
    bool completed;
} schedule;

typedef struct {
    schedule* queue[MAX_QUEUE_SIZE];
    int front;
    int rear;
    int size;
    sem_t semaphore;
} shared_memory;

void function1();
void destroy_shared_memory();
schedule* createProcess(int pid, clock_t stop);
void enqueue(schedule* job);
schedule* dequeue();
int getSize();
void start_job(schedule** job);
void stop_job(schedule** job);
void* simple_scheduler(void* args);
void submit(char* argv[], int count);
void print_completed_jobs();

#endif
