
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>

#define MAX_QUEUE_SIZE 1000
#define MAX_PROCESSES 100
#define CLOCKS_PER_MILLISECOND (CLOCKS_PER_SEC / 1000)
#define CLOCKS_PER_MICROSECOND (CLOCKS_PER_SEC / 1000000)

typedef struct schedule {
    int pid;
    clock_t completion_time; // To store the completion time
    int wait_time;
    clock_t stop;
    int running;
    bool completed; // To track if the job has completed
} schedule;

// Expanded shared memory structure
typedef struct {
    schedule* queue[MAX_QUEUE_SIZE];
    int front;
    int rear;
    int size;
    sem_t semaphore;
} shared_memory;

// Global pointer to shared memory and process array
shared_memory* ptr_to_shared_memory;
schedule* completed_jobs[MAX_PROCESSES]; // Array to store completed jobs
int completed_count = 0; // Counter for completed jobs

void function1() {
    int shm_fd = shm_open("/job_queue", O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open failed");
        exit(1);
    }

    if (ftruncate(shm_fd, sizeof(shared_memory)) == -1) {
        perror("ftruncate failed");
        exit(1);
    }

    ptr_to_shared_memory = mmap(NULL, sizeof(shared_memory), PROT_READ | PROT_WRITE,
                   MAP_SHARED, shm_fd, 0);
    if (ptr_to_shared_memory == MAP_FAILED) {
        perror("mmap failed");
        exit(1);
    }

    if (sem_init(&ptr_to_shared_memory->semaphore, 1, 1) == -1) {
        perror("sem_init failed");
        exit(1);
    }

    ptr_to_shared_memory->front = 0;
    ptr_to_shared_memory->rear = 0;
    ptr_to_shared_memory->size = 0;
}

void destroy_shared_memory() {
    sem_destroy(&ptr_to_shared_memory->semaphore);

    if (munmap(ptr_to_shared_memory, sizeof(shared_memory)) == -1) {
        perror("munmap failed");
    }

    if (shm_unlink("/job_queue") == -1) {
        perror("shm_unlink failed");
    }
}

schedule* createProcess(int pid, clock_t stop) {
    schedule* newProcess = (schedule*)malloc(sizeof(schedule));
    if (newProcess == NULL) {
        printf("Memory allocation failed\n");
        return NULL;
    }
    newProcess->pid = pid;
    newProcess->wait_time = 0;
    newProcess->stop = stop;
    newProcess->running = 0;
    newProcess->completed = false; // Initially not completed
    return newProcess;
}

void enqueue(schedule* job) {
    sem_wait(&ptr_to_shared_memory->semaphore);
    ptr_to_shared_memory->queue[ptr_to_shared_memory->rear] = job;
    ptr_to_shared_memory->rear = (ptr_to_shared_memory->rear + 1) % MAX_QUEUE_SIZE;
    ptr_to_shared_memory->size++;
    sem_post(&ptr_to_shared_memory->semaphore);
}

schedule* dequeue() {
    sem_wait(&ptr_to_shared_memory->semaphore);
    if (ptr_to_shared_memory->size == 0) {
        sem_post(&ptr_to_shared_memory->semaphore);
        return NULL;
    }
    schedule* job = ptr_to_shared_memory->queue[ptr_to_shared_memory->front];
    ptr_to_shared_memory->front = (ptr_to_shared_memory->front + 1) % MAX_QUEUE_SIZE;
    ptr_to_shared_memory->size--;
    sem_post(&ptr_to_shared_memory->semaphore);
    return job;
}

int getSize() {
    sem_wait(&ptr_to_shared_memory->semaphore);
    int size = ptr_to_shared_memory->size;
    sem_post(&ptr_to_shared_memory->semaphore);
    return size;
}

void start_job(schedule** job) {
    if (kill((*job)->pid, SIGCONT) == -1) {
        perror("Error resuming job");
    }
    (*job)->wait_time += (clock() - (*job)->stop);
}

void stop_job(schedule** job) {
    if (kill((*job)->pid, SIGSTOP) == -1) {
        perror("Error stopping job");
    }
    (*job)->stop = clock();
}

void* simple_scheduler(void* args) { // Scheduler function for thread
    int NCPU = *((int*)args); // Retrieve NCPU
    int TSLICE = *((int*)args + 1); // Retrieve TSLICE

    while (true) {
        if (getSize() == 0) {
            continue;
        }

        schedule* arr[NCPU];
        int sizeOfArr = 0;

        for (int i = 0; i < NCPU; i++) {
            schedule* job = dequeue();
            if (job == NULL) {
                break;
            }
//            printf("Scheduling pid: %d\n", job->pid);

            arr[sizeOfArr++] = job;
            start_job(&job);
        }

        usleep(TSLICE * 1000);

        for (int i = 0; i < sizeOfArr; i++) {
            schedule* job = arr[i];
            int status;

            stop_job(&job);

            int result = waitpid(job->pid, &status, WNOHANG);

            if (result == 0) {
                enqueue(job); // Job is still running, re-enqueue
            } else if (result > 0) {
                job->completed = true; // Mark as completed
                completed_jobs[completed_count++] = job; // Store completed job details
                free(job); // Free memory after completion
            } else {
                printf("waitpid error\n");
                enqueue(job); // Re-enqueue job on error
            }
        }
    }
}

void submit(char* argv[], int count) {
    int pid = fork();
    if (pid < 0) {
        printf("Fork failed\n");
        exit(1);
    } else if (pid == 0) {
        execvp(argv[0], argv);
        perror("Execution failed");
        exit(1);
    } else {
        kill(pid, SIGSTOP);
        printf("submit pid:%d\n", pid);
        schedule* job = createProcess(pid, clock());
        enqueue(job);
    }
}

void print_completed_jobs() {
    printf("\nCompleted Jobs Details:\n");
    for (int i = 0; i < completed_count; i++) {
        schedule* job = completed_jobs[i];
        printf("PID: %d, Wait Time: %ld, Completion Time: %ld\n",
               job->pid, job->wait_time/CLOCKS_PER_MICROSECOND, clock()/CLOCKS_PER_MICROSECOND);
    }
}