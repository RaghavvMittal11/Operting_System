#include "loader.h"
#include <stdbool.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <elf.h>
#include <signal.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>

Elf32_Ehdr *ehdr = NULL;
Elf32_Phdr *phdr = NULL;
int fd = -1;
int page_fault_count = 0;
int page_allocation_count = 0;
int internal_fragmentation = 0;

typedef int (*StartFuncType)(void);

void loader_cleanup() {
    if (ehdr) {
        free(ehdr);
        ehdr = NULL;
    }
    if (phdr) {
        free(phdr);
        phdr = NULL;
    }
    if (fd >= 0) {
        close(fd);
        fd = -1;
    }
}

void handle_page_fault(int sig, siginfo_t *si, void *context) {
    void *fault_addr = si->si_addr;
    page_fault_count++;

    int i = 0;
    while (i < ehdr->e_phnum) {
        if (phdr[i].p_type == PT_LOAD) {
            uintptr_t segment_start = phdr[i].p_vaddr;
            uintptr_t segment_end = segment_start + phdr[i].p_memsz;
            if ((uintptr_t)fault_addr >= segment_start && (uintptr_t)fault_addr < segment_end) {
                break;
            }
        }
        i++;
    }

    if (i == ehdr->e_phnum) {
        fprintf(stderr, "Segmentation fault: invalid access\n");
        loader_cleanup();
        exit(1);
    }

    uintptr_t page_start = (uintptr_t)fault_addr & ~(4095);
    void *mapped_mem = mmap((void *)page_start, 4096, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_FIXED | MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);

    if (mapped_mem == MAP_FAILED) {
        perror("mmap failed");
        loader_cleanup();
        exit(1);
    }

    page_allocation_count++;

    uintptr_t segment_offset = page_start - phdr[i].p_vaddr;
    if (segment_offset < phdr[i].p_filesz) {
        size_t copy_size = (segment_offset + 4096 <= phdr[i].p_filesz) ? 4096 : phdr[i].p_filesz - segment_offset;

        if (lseek(fd, phdr[i].p_offset + segment_offset, SEEK_SET) == -1 || read(fd, mapped_mem, copy_size) != copy_size) {
            perror("Error loading segment data");
            loader_cleanup();
            exit(1);
        }

        // Calculate and accumulate internal fragmentation for this page
        if (copy_size < 4096) {
            internal_fragmentation += (4096 - copy_size);
        }
    } else {
        // If the page is allocated but does not contain any segment data, the whole page is fragmented
        internal_fragmentation += 4096;
    }
}

void load_and_run_elf(char **argv) {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = handle_page_fault;
    sigaction(SIGSEGV, &sa, NULL);

    fd = open(argv[1], O_RDONLY);
    if (fd < 0) {
        perror("Error opening file");
        exit(1);
    }

    ehdr = malloc(sizeof(Elf32_Ehdr));
    if (ehdr == NULL) {
        perror("Error allocating memory");
        loader_cleanup();
        exit(1);
    }

    int readError = read(fd, ehdr, sizeof(Elf32_Ehdr));
    if (readError < 0) {
        printf("Error reading ELF header");
        loader_cleanup();
        exit(1);
    }

    if (ehdr->e_type != ET_EXEC) {
        fprintf(stderr, "Not an executable file\n");
        loader_cleanup();
        exit(1);
    }

    int noSeg = ehdr->e_phnum;
    int phdrSize = ehdr->e_phentsize;

    if(noSeg == 0){
        printf("No segment flag \n");
        exit(1);
    }
    if(phdrSize == 0){
        printf("No phdr flag \n");
        exit(1);
    }

    if(ehdr->e_phoff == 0){
        printf("No phdr flag \n");
        exit(1);
    }

    phdr = malloc(ehdr->e_phnum * ehdr->e_phentsize);
    if (phdr == NULL) {
        perror("Error allocating memory for program headers");
        loader_cleanup();
        exit(1);
    }

    if (lseek(fd, ehdr->e_phoff, SEEK_SET) == -1 || read(fd, phdr, ehdr->e_phnum * ehdr->e_phentsize) < 0) {
        perror("Error reading program headers");
        loader_cleanup();
        exit(1);
    }

    StartFuncType _start = (StartFuncType)(uintptr_t)ehdr->e_entry;
    int result = _start();
    printf("User _start return value = %d\n", result);

    printf("Total page faults: %d\n", page_fault_count);
    printf("Total page allocations: %d\n", page_allocation_count);
    printf("Total internal fragmentation: %d KB\n", internal_fragmentation / 1024);

    loader_cleanup();
}

int main(int argc, char** argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <ELF Executable>\n", argv[0]);
        exit(1);
    }
    load_and_run_elf(argv);
    return 0;
}

