#include "loader.h"
  #include <stdbool.h>
  #include <sys/mman.h>
  #include <fcntl.h>
  #include <unistd.h>
  #include <stdlib.h>
  #include <stdio.h>
  #include <elf.h>

  Elf32_Ehdr *ehdr = NULL;
  Elf32_Phdr *phdr = NULL;
  int fd = -1;
  typedef int (*StartFuncType)(void);

  void loader_cleanup()
  {
    if (ehdr)
    {
      free(ehdr);
      ehdr = NULL;
    }
    if (phdr)
    {
      free(phdr);
      phdr = NULL;
    }
    if (fd >= 0)
    {
      close(fd);
      fd = -1;
    }
  }

  void load_and_run_elf(char **argv)
  {
    fd = open(argv[1], O_RDONLY);

    if (fd < 0)
    {
      printf("Error opening file");
      exit(1);
    }

    ehdr = (Elf32_Ehdr *)malloc(sizeof(Elf32_Ehdr));
    if (ehdr == NULL)
    {
      printf("Error allocating memory");
      loader_cleanup();
      exit(1);
    }

    // MARK
    int readError = read(fd, ehdr, sizeof(Elf32_Ehdr));
    if (readError < 0)
    {
      printf("Error reading ELF header");
      loader_cleanup();
      exit(1);
    }

    if (ehdr->e_type != ET_EXEC)
    {
      fprintf(stderr, "Not an executable file\n");
      loader_cleanup();
      exit(1);
    }

// MARK
    int noSeg = ehdr->e_phnum;
    int phdrSize = ehdr->e_phentsize;

   if(noSeg == 0){
     printf("No segment flag \n");
     exit(1);
   }
  if(phdrSize == 0){
    printf("No phdr flag \n");
    exit(1);
  }

  if(ehdr->e_phoff == 0){
    printf("No phdr flag \n");
    exit(1);
  }

    phdr = (Elf32_Phdr *)malloc( noSeg * phdrSize );

    if (phdr == NULL)
    {
      printf("Error allocating memory");
      loader_cleanup();
      exit(1);
    }

    if (lseek(fd, ehdr->e_phoff, SEEK_SET) == -1)
    {
      printf("lseek failed to set seek");
      loader_cleanup();
      exit(1);
    }
// MARK
    int readError2 = read(fd, phdr, ehdr->e_phnum * ehdr->e_phentsize);
    if (readError2< 0)
    {
      printf("Error reading program headers");
      loader_cleanup();
      exit(1);
    }

    bool flag = false;
    void *virtual_mem = NULL;

    for (int i = 0; i < ehdr->e_phnum; i++)
    {
      if (phdr[i].p_type == PT_LOAD)
      {
        flag = true;

        virtual_mem = mmap((void *)(uintptr_t)phdr[i].p_vaddr, phdr[i].p_memsz, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_ANONYMOUS | MAP_PRIVATE, 0, 0);

        if (virtual_mem == MAP_FAILED)
        {
          printf("Error mapping memory");
          loader_cleanup();
          exit(1);
        }

        if (lseek(fd, phdr[i].p_offset, SEEK_SET) == -1)
        {
          printf("lseek failed to set seek");
          loader_cleanup();
          exit(1);
        }
        // MARK
        int readError3 = read(fd, virtual_mem, phdr[i].p_filesz);
        if (readError3 < 0)
        {
          printf("Error reading file");
          loader_cleanup();
          exit(1);
        }
      }
    }

    if (!flag)
    {
      fprintf(stderr, "No PT_LOAD segment flag\n");
      loader_cleanup();
      exit(1);
    }

    if (ehdr->e_entry == 0)
    {
      fprintf(stderr, "Invalid entry address\n");
      loader_cleanup();
      exit(1);
    }

    StartFuncType _start = (StartFuncType)(uintptr_t)ehdr->e_entry;
    int result = _start();
    printf("User _start return value = %d\n", result);

    loader_cleanup();
  }

  int main(int argc, char** argv)
  {
    if(argc != 2) {
      printf("Usage: %s <ELF Executable> \n",argv[0]);
      exit(1);
    }
    if(argv == NULL){
          printf("The given file is not acceptable");
          exit(1);
    }
    // 1. carry out necessary checks on the input ELF file
    // 2. passing it to the loader for carrying out the loading/execution
    load_and_run_elf(argv);
    // 3. invoke the cleanup routine inside the loader
    loader_cleanup();
    return 0;
  }
