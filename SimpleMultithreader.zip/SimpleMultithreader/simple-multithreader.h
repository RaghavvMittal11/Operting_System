#ifndef SIMPLE_MULTITHREADER_H
#define SIMPLE_MULTITHREADER_H

#include <pthread.h>
#include <functional>
#include <vector>
#include <ctime>
#include <iostream>

// Structure to hold thread arguments for 1D parallel_for
struct Temp1 {
    int low, high, chunk, threadId, numThreads;
    std::function<void(int)> lambda;
};

// Structure to hold thread arguments for 2D parallel_for
struct Temp2 {
    int low1, high1, low2, high2, chunk, threadId, numThreads;
    std::function<void(int, int)> lambda;
};

// Thread function for 1D parallel_for
void* func1(void* arg) {
    Temp1* args = (Temp1*) arg;
    for (int i = args->low; i < args->high; i++) {
        args->lambda(i);
    }
    return nullptr;
}

// Thread function for 2D parallel_for
void* func2(void* arg) {
    Temp2* args = (Temp2*) arg;
    for (int i = args->low1; i < args->high1; i++) {
        for (int j = args->low2; j < args->high2; j++) {
            args->lambda(i, j);
        }
    }
    return nullptr;
}

// 1D parallel_for implementation
void parallel_for(int low, int high, std::function<void(int)> &&lambda, int numThreads) {
    clock_t start_time = clock();

    pthread_t tid[numThreads];
    Temp1 args[numThreads];
    int chunk = (high - low) / numThreads;

    for (int i = 0; i < numThreads; i++) {
        args[i].low = low + i * chunk;
        args[i].high = (i == numThreads - 1) ? high : args[i].low + chunk;
        args[i].lambda = lambda;
        pthread_create(&tid[i], NULL, func1, (void*) &args[i]);
    }

    for (int i = 0; i < numThreads; i++) {
        pthread_join(tid[i], NULL);
    }

    clock_t end_time = clock();
    double duration = static_cast<double>(end_time - start_time) / CLOCKS_PER_SEC;
    std::cout << "Parallel execution time: " << duration << " seconds" << std::endl;
}

// 2D parallel_for implementation
void parallel_for(int low1, int high1, int low2, int high2, std::function<void(int, int)> &&lambda, int numThreads) {
    clock_t start_time = clock();

    pthread_t tid[numThreads];
    Temp2 args[numThreads];
    int chunk = (high1 - low1) / numThreads;

    for (int i = 0; i < numThreads; i++) {
        args[i].low1 = low1 + i * chunk;
        args[i].high1 = (i == numThreads - 1) ? high1 : args[i].low1 + chunk;
        args[i].low2 = low2;
        args[i].high2 = high2;
        args[i].lambda = lambda;
        pthread_create(&tid[i], NULL, func2, (void*) &args[i]);
    }

    for (int i = 0; i < numThreads; i++) {
        pthread_join(tid[i], NULL);
    }

    clock_t end_time = clock();
    double duration = static_cast<double>(end_time - start_time) / CLOCKS_PER_SEC;
    std::cout << "Parallel execution time: " << duration << " seconds" << std::endl;
}

#endif // SIMPLE_MULTITHREADER_H

